package com.Instagram.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Instagram.dao.InstagramDAOInterface;
import com.Instagram.entity.Employee;




@RestController
@RequestMapping("/instagram")
@CrossOrigin(origins="*",allowedHeaders = "*") 
public class InstagramController {
	
	@Autowired
   InstagramDAOInterface id1;
	
	@GetMapping("/user")
public List<Employee> viewProfile()
{
	List<Employee> list=id1.viewProfileDAO();
	return list;
}
 @PostMapping("/user")
	    public Employee createProfile(@RequestBody Employee e) {
	 System.out.println(e.getId());
	      return id1.createProfileDAO(e);
		
	    }
 @PutMapping(value="/user/{id}")
 public void updateProfile(@RequestBody Employee e, @PathVariable("id") int id) {
	 System.out.println(id);
      id1.updateProfileDAO(e,id);
     
 }
 @DeleteMapping(value="/user/{id}")
 public void deleteProfile(@PathVariable("id") int id) {
	 
     id1.deleteProfileDAO(id);
 }
}
