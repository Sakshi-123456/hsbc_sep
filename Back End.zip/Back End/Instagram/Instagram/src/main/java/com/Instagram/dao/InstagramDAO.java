package com.Instagram.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.Instagram.entity.Employee;
@Repository
public class InstagramDAO implements InstagramDAOInterface{

	public List<Employee> viewProfileDAO() {
		// TODO Auto-generated method stub
		List<Employee> l=new ArrayList<Employee>();
		Employee  e=null;
		Connection con=null;
		try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
	 con=DriverManager.getConnection("jdbc:derby:f:/firstdb1;create=true","sakshi","sakshi");
		PreparedStatement ps=con.prepareStatement("select * from InstagramUser");
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			e=new Employee();
			e.setName(rs.getString(2));
			e.setPassword(rs.getString(3));
			e.setEmail(rs.getString(4));
			e.setAddress(rs.getString(5));
			e.setId(rs.getInt(1));
			l.add(e);
			
		}
		}
		catch(ClassNotFoundException | SQLException e1)
		{
		e1.printStackTrace();
		}
		finally {
			try {
			con.close();
			}
			catch(SQLException e1)
			{
			e1.printStackTrace();
			}
		}
		System.out.println(e.getId());
		return l;
	
	}

	@Override
	public Employee createProfileDAO(Employee e) {
		// TODO Auto-generated method stub
		Employee ee=new Employee();
		Connection con=null;
		int i,j=0;
		PreparedStatement ps,ps1=null;
		try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con=DriverManager.getConnection("jdbc:derby:f:/firstdb1;create=true","sakshi","sakshi");
		ps=con.prepareStatement("insert into InstagramUser(Name,Password,Email,Address) values(?,?,?,?)");
		ps.setString(1,e.getName());
		ps.setString(2, e.getPassword());
		ps.setString(3,e.getEmail());
		ps.setString(4,e.getAddress());
		
		i=ps.executeUpdate();
		ps1=con.prepareStatement("select * from InstagramUser where Name=?");
		ps1.setString(1, e.getName());
		ResultSet rs=ps1.executeQuery();
		if(rs.next()) {
		ee.setName(rs.getString(2));
		ee.setPassword(rs.getString(3));
		ee.setEmail(rs.getString(4));
		ee.setAddress(rs.getString(5));
		ee.setId(rs.getInt(1));
		}
		}
		catch(ClassNotFoundException|SQLException e1)
		{
			e1.printStackTrace();
		}
		finally {
			try {
			con.close();
			}
			catch(SQLException e1)
			{
			e1.printStackTrace();
			}
		}
		
		System.out.println(ee.getId()+ee.getName()+ee.getPassword()+ee.getEmail()+ee.getAddress());
		return ee;
	}

	@Override
	public void deleteProfileDAO(int id) {
		// TODO Auto-generated method stub
		int rs=0;
	    Connection con=null;
	    try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con=DriverManager.getConnection("jdbc:derby:f:/firstdb1;create=true","sakshi","sakshi");
		PreparedStatement ps=con.prepareStatement("delete from InstagramUser where id=?");
		ps.setInt(1,id);
		
		rs=ps.executeUpdate();
		System.out.println(rs+"Deleted");
	    }
	    catch(ClassNotFoundException|SQLException e1)
		{
			e1.printStackTrace();
		}
		finally {
			try {
			con.close();
			}
			catch(SQLException e1)
			{
			e1.printStackTrace();
			}
		}
		
	}

	

	@Override
	public void updateProfileDAO(Employee e, int id) {
		// TODO Auto-generated method stub
		Connection con=null;
		int rs=0;
		try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con=DriverManager.getConnection("jdbc:derby:f:/firstdb1;create=true","sakshi","sakshi");
		PreparedStatement ps=con.prepareStatement("update InstagramUser set Name=?, Password=?, Email=?, Address=? where id=?");
		ps.setString(1,e.getName());
		ps.setString(2, e.getPassword());
		ps.setString(3,e.getEmail());
		ps.setString(4, e.getPassword());
		ps.setInt(5,id);
		
		 rs=ps.executeUpdate();
		}
		catch(ClassNotFoundException | SQLException e1)
		{
		e1.printStackTrace();
		}
		finally {
			try {
			con.close();
			}
			catch(SQLException e1)
			{
			e1.printStackTrace();
			}
		}
		
	}

}
