package com.Instagram.dao;

import java.util.List;

import com.Instagram.entity.Employee;

public interface InstagramDAOInterface {

	List<Employee> viewProfileDAO();

	Employee createProfileDAO(Employee e);

	void deleteProfileDAO(int id);

	

	void updateProfileDAO(Employee e, int id);

}
