import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';

import { AppComponent } from './app.component';
import { InstagramComponent } from './instagram.component';
import { InstagramService } from './instagram.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    InstagramComponent,
    
   
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
   
  ],
  providers: [InstagramService],
  bootstrap: [AppComponent]
})
export class AppModule { }
