import { Injectable } from '@angular/core';
import { instagram } from './instagram';
import { HttpClient } from '@angular/common/http';


@Injectable()          //service class 
export class InstagramService {
  private baseUrl = 'http://localhost:10000';

  constructor(private http: HttpClient) { }   //DI

 viewProfile():  Promise<instagram[]> {
    return this.http.get(this.baseUrl + '/instagram/user/')
      .toPromise()
      .then(response => response as instagram[])
      .catch(this.handleError);
	  }
    createProfile(insta:instagram): Promise<instagram> {
      return this.http.post(this.baseUrl + '/instagram/user/', insta)
        .toPromise().then(response => response as instagram)
        .catch(this.handleError);
    }
    deleteProfile(id:number): Promise<any> {
      return this.http.delete(this.baseUrl + '/instagram/user/' +id)
        .toPromise()
        .catch(this.handleError);
    }
    updateUser(insta: instagram): Promise<instagram> {
      console.log(insta);
      return this.http.put(this.baseUrl + '/instagram/user/' + insta.id, insta)
        .toPromise()
        .then(response => response as instagram[])
        .catch(this.handleError);
    }
   
  
  private handleError(error: any): Promise<any> {
    console.error('Some error occured', error);      // print the error
    return Promise.reject(error.message || error);  //return promise object that is being rejected because of some reason
  }
}