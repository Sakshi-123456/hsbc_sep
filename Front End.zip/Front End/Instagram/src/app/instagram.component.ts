import { Component, Input, OnInit } from '@angular/core';
import { InstagramService } from './instagram.service';
import { instagram } from './instagram';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'instagram',
  templateUrl: './instagram.component.html'
})

export class InstagramComponent implements OnInit {
	insta: instagram[];
  newInstagram: instagram = new instagram();
  editingIndex: number = -1;
  editingUser: instagram = new instagram();

	constructor(
	  private instagramService:  InstagramService,
	) {}

	ngOnInit(): void {
		this.viewProfile();
  }

  viewProfile(): void {
    this.instagramService.viewProfile()
      .then(instagram => this.insta = instagram );  	
  }
  createProfile(instagramForm: NgForm): void {
    this.instagramService.createProfile(this.newInstagram)
      .then( createProfile=> {        
        instagramForm.reset();  //reset the form
	      this.newInstagram = new instagram();
	      this.insta.unshift(createProfile) //element added on the first position of list
      });
  }
  deleteProfile(id :number): void {
  	this.instagramService.deleteProfile(id)
  	.then(() => {
  		this.insta = this.insta.filter(insta => insta.id != id); //create new list which does not satisfy the condition
  	});
  }
  /*updateProfile(name: string): void {
  	this.instagramService.updateProfile(name)
  	.then(() => {
  		this.insta = this.insta.filter(insta => insta.name != name); //create new list which does not satisfy the condition
    });*/
    
    editUser(user:instagram,i:number):void{
      this.editingIndex=i;
      Object.assign(this.editingUser,user);
    }
    updateUser(user:instagram): void{
       console.log(user);
      this.instagramService.updateUser(user)
      .then(() =>{
        Object.assign( this.insta[this.editingIndex], this.editingUser)
      this.clearEditing();
    });
  }
    clearEditing(): void{
      this.editingUser=new instagram();
      this.editingIndex=-1;
    }
}

