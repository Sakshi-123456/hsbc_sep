export class instagram {
    name: string;
    password: string;
    email: string;
    address: string;
    id: number;
  }